package org.koreait.config;

public class ControllerConfig {

}
