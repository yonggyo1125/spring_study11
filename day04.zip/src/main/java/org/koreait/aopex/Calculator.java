package org.koreait.aopex;

public interface Calculator {
	long factorial(long num);
}
